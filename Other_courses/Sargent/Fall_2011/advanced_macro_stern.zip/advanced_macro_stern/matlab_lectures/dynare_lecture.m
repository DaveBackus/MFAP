clc; clear all; close all; format('compact');%Cleans up the workspace

%% Model
% *Utility*: $$u(c) = \frac{c^{1 - \gamma}}{1 - \gamma}, u'(c) = c^{-\gamma}$
%%
% *Production*: $$f(k) = k^{\alpha}, f'(k) = \alpha k^{\alpha - 1}$
%%
% *Feasibility*: $$k_t = f(k_{t-1}) + (1 - \delta)k_{t-1} - c_t - g_t$
%% 
% *Feasibility(substituted)*: $$k_t = k_{t-1}^{\alpha} + (1-\delta)k_{t+1} - c_t - g_t$

%%
% *Euler Equation*: $$u'(c_t) = \beta u'(c_{t+1})\left((1-\delta)+f'(k_{t+1}) \right)$
%% 
% *Euler Equation(substituted)*: $$c_t^{-\gamma} = \beta c_{t+1}^{-\gamma}\left((1-\delta) + \alpha k^{\alpha - 1}\right)$

%% Running Dynare: Anticipated Change in G
% *Write equations in separate module file:neoclassical_growth_anticipated_g.mod*
% Dynare puts the results of the simulation in vectors
% The names match variables declared in the 'var' section of the mod file

% Dynare has the following convention on the output of simulated variables
% Given simulation of length N and a variable such as c
% c(1) holds the initial values (often the pre-shock steady state).
% c(2:N+1) contains the simulated values
% c(N+2) contains the terminal value (a steady state)

dynare neoclassical_growth_anticipated_g
%% Results of the Simulation: Anticipated Change in G
% Let T be the periods to plot.  A portion of the simulation length
T=40;
sim_periods = length(c) - 2; %See above notes on the dynare output

% Now we plot the responses of the endogenous variables to the shock.
t_axis=0:T-1; %The time dimension, x axis, to plot

%This sets up a figure.  See matlab help on 'figure'
figure(1) 

% subplot for capital 'k'
subplot(2,3,1) % This tells matlab to plot multiple graphs in the figure
plot(t_axis,k(1:T))
title('k','Fontsize',12)

% subplot for consumption 'c'
subplot(2,3,2)
plot(t_axis,c(2:T+1))
title('c','Fontsize',12)

% calculate: eta_t = r_t / q_t = f'(k_t)
eta = alpha * k(1:T).^(alpha - 1);
subplot(2,3,3)
plot(t_axis,eta(1:T))
title('r_t/q_t','Fontsize',12)

% calculate: (R_t)^{-1} = beta u'(c_{t+1})/u'(c_t)
R=c(2:T+1).^(-gamma)./(beta*c(3:T+2).^(-gamma));

subplot(2,3,4)
plot(t_axis,R(1:T))
title('R_t','Fontsize',12)

% calculate the yield curves at t=0,t=10,t=60
% computing the price system : q and steady state price system qs(t)=beta^t
%q(2) is normalized to 1

for n=1:length(c)
    q(n)=beta^n*c(n).^(-gamma)/(beta^2*c(2)^(-gamma));
end

%computing the short term interest rates
%computing the term structure for n=1 to 40 for all periods
n_term_start = 60; %Maximum length to calculate the start of the term structure.
for t=1:n_term_start + 2 %Given   In r_{t, t+s}, these are the 't's.
    for s=1:T %Calculates for s = 1,...T periods
        yield_curve(s,t)=log(q(s+t)/q(t))/-s; %Matrix: r_{t, t+s} = yield_curve(s, t)
    end
end

subplot(2,3,5)
%The following plots all 3 yield curves in a single graph:
% s=1 is solid, set in the code by the 'k'
% s=10 is dashed with dots, set in the code by the '-.k'
% s=60 is dashed, set in the code by the '--k'
plot(t_axis,yield_curve(:,2),'k', t_axis,yield_curve(:,11),'-.k',t_axis,yield_curve(:,61),'--k')
title('Yield curves(t=0,10,60)')

%% Running Dynare: Convergence to Steady State
% *Write equations in separate module file:neoclassical_growth_dynamics.mod*
% This uses constant government expenditures but looks at the convergence of the model
% off of the steady state with k_0 < k_ss

dynare neoclassical_growth_dynamics
%% Results of the Simulation: Convergence to Steady State
% Let T be the periods to plot.  A portion of the simulation length
T=40;

% Now we plot the responses of the endogenous variables to the shock.
t_axis=0:T-1; %The time dimension, x axis, to plot

%This sets up a figure.  See matlab help on 'figure'
figure(1) 

% subplot for capital 'k'
subplot(2,3,1) % This tells matlab to plot multiple graphs in the figure
plot(t_axis,k(1:T))
title('k','Fontsize',12)

% subplot for consumption 'c'
subplot(2,3,2)
plot(t_axis,c(2:T+1))
title('c','Fontsize',12)

% calculate: eta_t = r_t / q_t = f'(k_t)
eta = alpha * k(1:T).^(alpha - 1);
subplot(2,3,3)
plot(t_axis,eta(1:T))
title('r_t/q_t','Fontsize',12)

% calculate: (R_t)^{-1} = beta u'(c_{t+1})/u'(c_t)
R=c(2:T+1).^(-gamma)./(beta*c(3:T+2).^(-gamma));

subplot(2,3,4)
plot(t_axis,R(1:T))
title('R_t','Fontsize',12)

% calculate the yield curves at t=0,t=10,t=60
% computing the price system : q and steady state price system qs(t)=beta^t
%q(2) is normalized to 1

for n=1:length(c)
    q(n)=beta^n*c(n).^(-gamma)/(beta^2*c(2)^(-gamma));
end

%computing the short term interest rates
%computing the term structure for n=1 to 40 for all periods
n_term_start = 60; %Maximum length to calculate the start of the term structure.
for t=1:n_term_start + 2 %Given   In r_{t, t+s}, these are the 't's.
    for s=1:T %Calculates for s = 1,...T periods
        yield_curve(s,t)=log(q(s+t)/q(t))/-s; %Matrix: r_{t, t+s} = yield_curve(s, t)
    end
end

subplot(2,3,5)
%The following plots all 3 yield curves in a single graph:
% s=0 is solid
% s=10 is dashed with dots
% s=60 is dashed
plot(t_axis,yield_curve(:,2),'k', t_axis,yield_curve(:,11),'-.k',t_axis,yield_curve(:,61),'--k')
title('Yield curves(t=0,10,60)')

%% How to Install and Run Dynare
% * Install Dynare from: http://www.dynare.org/download/dynare-4.2  Remember where you installed it, I will use the path c:\apps\dynare
% * Follow instructions in the readme.txt that opens.
% * The only thing you really need to do is include the directory of the folder you installed in with the "Set Path" menu command.
% * For example, my directory to add to the Matlab path is: C:\apps\dynare\4.2.2
% * Choose 'Add Folder'.  Do NOT choose Add with subfolders.
% * VCL: Sorry.  I don't think VCL permissions for executing processes on the VCL.
% So for now, use with your own copy of matlab, or consider installing Octave as an open source replacement if you don't have matlab.
% Maybe we could ask VCL or the Stern computing lab to add in dynare if you really want to work with it.
%% How to Test your Dynare Installation
% * In matlab change the directory to C:\apps\dynare\4.2.2\examples or wherever you installed dynare
% * In the matlab console:  dynare example1
% * This should do a bunch of calculations and generate graphs.
% * You can look at file example1.mod