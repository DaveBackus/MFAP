clc; clear all; close all; format('compact');%Cleans up the workspace

%% Creating Variables
% *Scalars, row vectors, and column vectors*
x = 4
x = [4] %Same thing, scalar = 1x1 vector
y = [1 2 3] %Row vector
z = [2; 2; -1;] %Column vector
%%
% *Some operations*
z' %Transpose: Switches column vs. row
2 * y %Scalar multiplication
y + z' %Add vector
y + 2*z' %Combination of the two
%y + z %Fails.  Why?
%%
% *Some more*
z = [2; 2; -1];
sum(z) %Sums up the vector
abs(z) %Absolute value of elements of z
4 * 10^(-5) %Scientific notation: 4.0000E-05
x = 1:5 %Generate vector as sequence from 1 to 5

%%
% *Display without the semi-colon*
x = 4; %No display, but assigns 4 to variable x
x = 4 % Assigns and displays
y = x + 3; %No display, but calculates and assigns
y = x + 3
x + 3 %Displays, but doesn't assign the results to any variable

%% Matrices
% *Basic operations*
A = [1 2 3; 4 5 6] % Define a 2x3 matrix
A' %Transpose, becomes a 3x2 matrix
2 * A %Scalar multiple
A(:,1) % Extract a column as a vector
A(2,:) % Extract a row as a vector
A(2,3) % Extract a value as a scalar
%% 
%
% *Some more, special matrices*
eye(2) %Create the identity matrix of size 2x2
zeros(2,1) %Create a matrix of zeros of size 2x1
A = [1 2 3; 4 5 6];
x = [7 8 9];
[A; x] %Stack matrices/vectors

%% 
% *Multiplication and conformance*
A = [1 2 3; 4 5 6];
x = [1; 2; 3];
A * x %Matrix-vector multiplication. 2x3 * 3x1
x' * A' %Matches: 1x3 * 3x2
%x * A %Error, 3x1 * 2x3
% Matlab: ??? Error using ==> mtimes Inner matrix dimensions must agree.
B = [1 2; 3 4];
eye(2) * B %Returns B
B * eye(2) %Returns B
eye(3) * x %Returns x

%% 
% *Inverses and systems of equations*
A = [2 1; 3 2];
y = [3;2]; %Row Vector
inv(A)
inv(A) * A
A * inv(A)
inv([4]) %Special case of a scalar.
B = [1 2 3; 4 5 6];
%inv([0]) %ERROR: Why does this fail?
%inv(B) %ERROR: Why does this fail?

%%
% *Systems of equations*
%System: A x = y.  Solve for x
A = [2 1; 3 2];
y = [3;2];
x = inv(A) * y %inv(A)*A*x = inv(A) * y => I*x = inv(A)*y
A * x %Shows this solves it correctly
x = A \ y %Another way to solve Ax = y

%% Transition matrices
% *Predicting the next state*
A = [.9 .1; .2 .8]; %Probability transition.Rows sum to 1:= stochastic matrix
x = [1 0]; %Current state (i.e. in state 1)
x * A % Probability over states next period
(x * A) * A % Probability over states in 2 periods
x * A^1000 % Probability over states in 1000 periods
p = [1 0] * A^1000 % ...if started in state 1
p = [0 1] * A^1000 % ...if started in state 2.  Same!
p * A % Note that p * A = 1 * p

%% Eigenvalues and Eigenvectors
% 
% * Right eigenvalue, eigenvector: 'd, x' solving: A * x = d*x
% * Left eigenvalue, eigenvector: 'd, x' solving: x' * A = d*x'
% * 'd, k*x' is also eigenvalue/eigenvector. Multiply both sides by k: k*x'*A=d*k*x'
A = [.1 .1 .8; 0 .5 .5; .5 0 .5]; %probability transition.
[X, d] = eigs(A) %eigenvalues in diagonal of 'd', eigenvectors in columns of 'X'
% Is eigenvalue = 1 important?  Does it always exist?
d(1,1) %First Eigenvalue.  eigs() puts them in order of size.
%%
% *Checking these are eigenvalues*
X(:,1) %Right eigenvector associated with first eigenvalue... could do for 2, 3
%Test if the answer is close to zero
A * X(:,1) - d(1,1) * X(:,1) %They are the same!  Note scientific notation.
A * X(:,2) - d(2,2) * X(:,2) %2nd also solves it.
A * (-1.1 * X(:,2)) - d(2,2) * (-1.1 * X(:,2)) %A multiple of 2nd also solves it.

%%
% *Finding the left eigenvector*
[X, d] = eigs(A') %Find eigenvectors for A' instead
%The largest eigenvalue is '1'.  Is this special?
pi = X(:,1); %Gets the eigenvector associated with the eigenvalue of 1
pi = pi / sum(pi) %*(1/sum(pi)) so that sum(pi) = 1, still eigenvector
pi' * A - 1 * pi' %This solves the equation with the eigenvalue of '1'
[1 0 0] * A^1000 %Interpretation: Compare to the eigenvector

%%
% *Another example*
A = [.9 .1 0 0; .1 .9 0 0; 0 .1 .8 .1; 0 0 0 1] %probability transition
% Interpret an agent starting in state 1, 2, 3, and 4
[X, d] = eigs(A') %Two eigenvalues = 1?
pi = X(:,1) / sum(X(:,1)) %First left eigenvector. Interpret for agent in state 4
pi = X(:,2) / sum(X(:,2)) %Second. Interpret for agent in state 1 and 2


%% Asset Pricing
% *Dividend process*: $$y_{t+1} = a + b y_t + c y_{t-1}$
%%
% *State*: $$x_t = \left[\begin{array}{ccc} 1 & y_t & y_{t-1} \\ \end{array}\right]'$
%%
% *Evolution*: $$A = \left[\begin{array}{ccc} 1 & 0 & 0 \\ a & b & c \\ 0 & 1 & 0\\ \end{array}\right]$
%%
% *Observation*: $$G = \left[\begin{array}{ccc} 0 & 1 & 0 \\ \end{array}\right]$
%%
% *Model*:
% $$x_{t+1} = A x_t, y_t = G x_t$
%%
% *Setting up some constants*
a = 1; %Example constants
b = 0.5;
c = -.1;

A = [1 0 0;
    a b c;
    0 1 0]; %Evolution
G = [0 1 0]; %Observation Equation
%% 
% *Pricing*: $$p_t = y_t + \beta p_{t+1}$
%%
% *Guess*: $$p_t = H x_t$
%%
% *Forecast Formula*: $$H = G (I - \beta A)^{-1}$
beta = .9; %Discount rate
H = G * inv(eye(3) - beta * A); %Forecasting formula

%%
% *Check convergence*: $$|eig(\beta A)|< 1$
abs(eigs(beta * A)) %If < 1, then H should work

%%
% *Pricing examples*
x_t = [1 1 1.1]'; %Set x_t if y_t = 1 and y_{t-1} = 1.1
price_t = H * x_t %Pricing formula with this x_t
x_tp1 = A * x_t % The state evolves according to A
price_tp1 = H * x_tp1 %The price next period becomes...
A^100 * x_t % What is x_{t+100}?
H * A^100 * x_t %What is the price at time=t+100
A^101 * x_t % What is x_{t+101}?
H * A^101 * x_t %What is the price at time=t+101

%% 
% *Can convergence fail?*
% *Dividend process*: $$y_{t+1} = 2.0 y_t - .1 y_{t-1}$
%%
% *State*: $$x_t = \left[\begin{array}{cc} y_t & y_{t-1} \\ \end{array}\right]'$
%%
% *Evolution*: $$A = \left[\begin{array}{cc} 2 & -.1 \\ 1 & 0\\ \end{array}\right]$
beta = .9;
A = [2 -.1; 1 0];
abs(eigs(beta * A)) %Fails
beta = .5;
abs(eigs(beta * A)) %Beta is low enough to converge now

%% Stochastic Asset Pricing
% *Dividend process*: $$y_{t+1} = a + b y_t + c y_{t-1} + d \epsilon_{t+1}$
%%
% Added $\epsilon$.  Standard normal with mean=0 and variance=1
%%
% *State*: $$x_t = \left[\begin{array}{ccc} 1 & y_t & y_{t-1} \\ \end{array}\right]'$
%%
% *Evolution*: $$A = \left[\begin{array}{ccc} 1 & 0 & 0 \\ a & b & c \\ 0 & 1 & 0\\ \end{array}\right]$
%%
% *Variance*: $$V = \left[\begin{array}{ccc} 0 & d & 0\\\end{array}\right]'$
%%
% *Observation*: $$G = \left[\begin{array}{ccc} 0 & 1 & 0 \\ \end{array}\right]$
%%
% *Pricing*: $$p_t = H x_t$
%%
% *System Evolution*:
% $$x_{t+1} = A x_t + V \epsilon_{t+1}$
%% 
% *Observation for both y and p:*
% $$\left[\begin{array}{c} y_t \\ p_t \\ \end{array}\right]=\left[\begin{array}{c} G \\ H \\ \end{array}\right] x_t + 0 \epsilon_{t+1}$
a = 1;
b = 0.5;
c = -.1;
d = .5;
beta = .9; %Discount rate

A = [1 0 0;
    a b c;
    0 1 0]; %Evolution
V = [0 d 0]'; %Variance
G = [0 1 0]; %Observation Equation
H = G * inv(eye(3) - beta * A); %Forecasting formula

%Stack to get 2 observables: y and p
F =  [G; H];
J = zeros(2,1); %These are the shocks on the 2 observables.  No uncertainty here

% Create a discrete state-space model from Matlab Control Toolkit
sys = ss(A, V, F, J, []); %The new variable 'sys' contains the model

%%
% *Simulating the model*
% Create shocks from random normal variables ~ N(0,1)
num_shocks = 10;
shocks = randn(num_shocks, 1); %Draws a 10x1 vector of normal random numbers
 
%Initial x to start the system for simulation
x_0 = [1 1.4 1.1]; %i.e. y_t = 1.4, y_{t-1} = 1.1

%Simulate this model with 'lsim' from this initial value with these shocks
%Top graph is y_t, bottom graph is p_t.
%Grey line is the identical shock (due to scale, they may look different)
lsim(sys, shocks, 0:num_shocks-1, x_0);

%What would happen if A, C, or G changed?  H changes.
%Pricing adjusts to changes in expectations of the future.

%% 
% *Impulse Response Simulation*

% What would dividend process converge to if there were no uncertainty?
% It is the 'y' such that y = y_t = y_{t-} = y_{t+1} ...
% Solve: y = a + b y + c y
% Solution is: y = a/(1 - c - b), Assume that (1 - c - b) > 0 and solve
y_stationary = a/(1 - c - b);
x_0 = [1 y_stationary y_stationary]; %Use this as the initial value

%Instead of a random set of shocks, put \epsilon_0 = 1 and \epsilon_t = 0
num_shocks = 10;
shocks = zeros(num_shocks, 1); %Set them all to zero
shocks(1,1) = 1; %Then change the first element.  1 standard deviation
%Note this is multiplied by 'd' in the evolution

%Simulate from the initial value.
lsim(sys, shocks, 0:num_shocks-1, x_0);

%This is called an 'impulse response'.  Allows you to see how long a 
%shock takes to work through the dividend and prices.

%% A Few Utilities
% * To clean up the workspace.  Use: |clc; clear all; close all;|
% * Comment with |%| in your files
% * Display text with |disp('mystring')|
% * Generate sequence with |1:10|
% * Plot with plot(X,Y)
disp('Displays your text'); %A comment
x = 1:5;
y = [1 4 9 16 25] ; %Sequence. y = x^2. Size of y must match size of x
plot(x,y); %Plots points: (x_1, y_1), (x_2, y_2), etc.

%% Working with Files
% * In Matlab, go to menu: File/New/Script to create a new .m file.
% * Type in all of your commands and save the file
% * You can run the whole file by pressing F5 or 'run'
% * After running a file, you can display variables, run commands as normal
% * If using VCL, remember to save the file to your local computer!